package entite;

public enum TypeCompte {
     Courant, Epargne
}
