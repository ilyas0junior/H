package serveur;

import javax.xml.ws.Endpoint;
import service.BibliothequeService;

public class ServeurJaxWS {

    public static void main(String[] args) {
        String url = "http://0.0.0.0:8787/";
        Endpoint.publish(url, new BibliothequeService());
        System.out.println("Serveur Bibliothèque démarré...");
        System.out.println("URL : " + url);
    }
}
