package entite;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Livre {

    private int id;
    private String titre;
    private double prixJour;
    private boolean emprunte;

    public Livre() {
        super();
    }

    public Livre(int id, String titre,  double prixJour) {
        this.id = id;
        this.titre = titre;
        this.prixJour = prixJour;
        this.emprunte = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    

    public double getPrixJour() {
        return prixJour;
    }

    public void setPrixJour(double prixJour) {
        this.prixJour = prixJour;
    }

    public boolean isEmprunte() {
        return emprunte;
    }

    public void setEmprunte(boolean emprunte) {
        this.emprunte = emprunte;
    }

    @Override
    public String toString() {
        return "Livre [id=" + id + ", titre=" + titre + 
               ", prixJour=" + prixJour + ", emprunte=" + emprunte + "]";
    }
}

