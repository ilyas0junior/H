package service;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebService;

import entite.Livre;

@WebService(serviceName = "BibliothequeWS")
public class BibliothequeService implements IBibliotheque {

    private Map<Integer, Livre> livres = new HashMap<>();

    public BibliothequeService() {
        livres.put(1, new Livre(1, "Java Avancé", 10));
        livres.put(2, new Livre(2, "Spring Boot", 12));
        livres.put(3, new Livre(3, "Web Services", 8));
    }

    @WebMethod
    public synchronized Livre getLivre(int id) throws BibliothequeException {
        Livre l = livres.get(id);
        if (l == null)
            throw new BibliothequeException("Livre introuvable : " + id);
        return l;
    }

    @WebMethod
    public synchronized List<Livre> afficherTousLesLivres() {
        return new ArrayList<>(livres.values());
    }

    @WebMethod
    public synchronized void emprunterLivre(int id) throws BibliothequeException {
        Livre l = getLivre(id);
        if (l.isEmprunte())
            throw new BibliothequeException("Livre déjà emprunté");
        l.setEmprunte(true);
    }

    @WebMethod
    public synchronized void retournerLivre(int id) throws BibliothequeException {
        Livre l = getLivre(id);
        if (!l.isEmprunte())
            throw new BibliothequeException("Livre non emprunté");
        l.setEmprunte(false);
    }

    @WebMethod
    public synchronized double calculerMontant(int id, int nombreJours)
            throws BibliothequeException {

        if (nombreJours <= 0)
            throw new BibliothequeException("Nombre de jours invalide");

        Livre l = getLivre(id);
        return l.getPrixJour() * nombreJours;
    }
}

