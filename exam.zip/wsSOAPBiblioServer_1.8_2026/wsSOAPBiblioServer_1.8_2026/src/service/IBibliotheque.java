package service;

import java.util.List;
import entite.Livre;

public interface IBibliotheque {

    Livre getLivre(int id) throws BibliothequeException;

    List<Livre> afficherTousLesLivres() throws BibliothequeException;

    void emprunterLivre(int id) throws BibliothequeException;

    void retournerLivre(int id) throws BibliothequeException;

    double calculerMontant(int id, int nombreJours) throws BibliothequeException;
}
