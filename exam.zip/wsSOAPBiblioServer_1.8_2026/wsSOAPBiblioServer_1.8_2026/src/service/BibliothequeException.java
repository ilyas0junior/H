package service;

import javax.xml.ws.WebFault;

@WebFault(name = "BibliothequeFault")
public class BibliothequeException extends Exception {

    public BibliothequeException(String message) {
        super(message);
    }
}
