
package service;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the service package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EmprunterLivre_QNAME = new QName("http://service/", "emprunterLivre");
    private final static QName _GetLivre_QNAME = new QName("http://service/", "getLivre");
    private final static QName _EmprunterLivreResponse_QNAME = new QName("http://service/", "emprunterLivreResponse");
    private final static QName _CalculerMontant_QNAME = new QName("http://service/", "calculerMontant");
    private final static QName _GetLivreResponse_QNAME = new QName("http://service/", "getLivreResponse");
    private final static QName _BibliothequeFault_QNAME = new QName("http://service/", "BibliothequeFault");
    private final static QName _AfficherTousLesLivres_QNAME = new QName("http://service/", "afficherTousLesLivres");
    private final static QName _Livre_QNAME = new QName("http://service/", "livre");
    private final static QName _CalculerMontantResponse_QNAME = new QName("http://service/", "calculerMontantResponse");
    private final static QName _AfficherTousLesLivresResponse_QNAME = new QName("http://service/", "afficherTousLesLivresResponse");
    private final static QName _RetournerLivreResponse_QNAME = new QName("http://service/", "retournerLivreResponse");
    private final static QName _RetournerLivre_QNAME = new QName("http://service/", "retournerLivre");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: service
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BibliothequeException }
     * 
     */
    public BibliothequeException createBibliothequeException() {
        return new BibliothequeException();
    }

    /**
     * Create an instance of {@link AfficherTousLesLivres }
     * 
     */
    public AfficherTousLesLivres createAfficherTousLesLivres() {
        return new AfficherTousLesLivres();
    }

    /**
     * Create an instance of {@link CalculerMontant }
     * 
     */
    public CalculerMontant createCalculerMontant() {
        return new CalculerMontant();
    }

    /**
     * Create an instance of {@link GetLivreResponse }
     * 
     */
    public GetLivreResponse createGetLivreResponse() {
        return new GetLivreResponse();
    }

    /**
     * Create an instance of {@link EmprunterLivreResponse }
     * 
     */
    public EmprunterLivreResponse createEmprunterLivreResponse() {
        return new EmprunterLivreResponse();
    }

    /**
     * Create an instance of {@link EmprunterLivre }
     * 
     */
    public EmprunterLivre createEmprunterLivre() {
        return new EmprunterLivre();
    }

    /**
     * Create an instance of {@link GetLivre }
     * 
     */
    public GetLivre createGetLivre() {
        return new GetLivre();
    }

    /**
     * Create an instance of {@link RetournerLivre }
     * 
     */
    public RetournerLivre createRetournerLivre() {
        return new RetournerLivre();
    }

    /**
     * Create an instance of {@link AfficherTousLesLivresResponse }
     * 
     */
    public AfficherTousLesLivresResponse createAfficherTousLesLivresResponse() {
        return new AfficherTousLesLivresResponse();
    }

    /**
     * Create an instance of {@link RetournerLivreResponse }
     * 
     */
    public RetournerLivreResponse createRetournerLivreResponse() {
        return new RetournerLivreResponse();
    }

    /**
     * Create an instance of {@link CalculerMontantResponse }
     * 
     */
    public CalculerMontantResponse createCalculerMontantResponse() {
        return new CalculerMontantResponse();
    }

    /**
     * Create an instance of {@link Livre }
     * 
     */
    public Livre createLivre() {
        return new Livre();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmprunterLivre }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "emprunterLivre")
    public JAXBElement<EmprunterLivre> createEmprunterLivre(EmprunterLivre value) {
        return new JAXBElement<EmprunterLivre>(_EmprunterLivre_QNAME, EmprunterLivre.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLivre }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "getLivre")
    public JAXBElement<GetLivre> createGetLivre(GetLivre value) {
        return new JAXBElement<GetLivre>(_GetLivre_QNAME, GetLivre.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmprunterLivreResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "emprunterLivreResponse")
    public JAXBElement<EmprunterLivreResponse> createEmprunterLivreResponse(EmprunterLivreResponse value) {
        return new JAXBElement<EmprunterLivreResponse>(_EmprunterLivreResponse_QNAME, EmprunterLivreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculerMontant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "calculerMontant")
    public JAXBElement<CalculerMontant> createCalculerMontant(CalculerMontant value) {
        return new JAXBElement<CalculerMontant>(_CalculerMontant_QNAME, CalculerMontant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLivreResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "getLivreResponse")
    public JAXBElement<GetLivreResponse> createGetLivreResponse(GetLivreResponse value) {
        return new JAXBElement<GetLivreResponse>(_GetLivreResponse_QNAME, GetLivreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BibliothequeException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "BibliothequeFault")
    public JAXBElement<BibliothequeException> createBibliothequeFault(BibliothequeException value) {
        return new JAXBElement<BibliothequeException>(_BibliothequeFault_QNAME, BibliothequeException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AfficherTousLesLivres }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "afficherTousLesLivres")
    public JAXBElement<AfficherTousLesLivres> createAfficherTousLesLivres(AfficherTousLesLivres value) {
        return new JAXBElement<AfficherTousLesLivres>(_AfficherTousLesLivres_QNAME, AfficherTousLesLivres.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Livre }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "livre")
    public JAXBElement<Livre> createLivre(Livre value) {
        return new JAXBElement<Livre>(_Livre_QNAME, Livre.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculerMontantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "calculerMontantResponse")
    public JAXBElement<CalculerMontantResponse> createCalculerMontantResponse(CalculerMontantResponse value) {
        return new JAXBElement<CalculerMontantResponse>(_CalculerMontantResponse_QNAME, CalculerMontantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AfficherTousLesLivresResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "afficherTousLesLivresResponse")
    public JAXBElement<AfficherTousLesLivresResponse> createAfficherTousLesLivresResponse(AfficherTousLesLivresResponse value) {
        return new JAXBElement<AfficherTousLesLivresResponse>(_AfficherTousLesLivresResponse_QNAME, AfficherTousLesLivresResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetournerLivreResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "retournerLivreResponse")
    public JAXBElement<RetournerLivreResponse> createRetournerLivreResponse(RetournerLivreResponse value) {
        return new JAXBElement<RetournerLivreResponse>(_RetournerLivreResponse_QNAME, RetournerLivreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetournerLivre }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "retournerLivre")
    public JAXBElement<RetournerLivre> createRetournerLivre(RetournerLivre value) {
        return new JAXBElement<RetournerLivre>(_RetournerLivre_QNAME, RetournerLivre.class, null, value);
    }

}
