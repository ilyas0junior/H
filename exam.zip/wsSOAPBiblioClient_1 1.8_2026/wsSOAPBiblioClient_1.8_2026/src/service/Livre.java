
package service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour livre complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="livre">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="titre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prixJour" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="emprunte" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "livre", propOrder = {
    "id",
    "titre",
    "prixJour",
    "emprunte"
})
public class Livre {

    protected int id;
    protected String titre;
    protected double prixJour;
    protected boolean emprunte;

    /**
     * Obtient la valeur de la propri�t� id.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * D�finit la valeur de la propri�t� id.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Obtient la valeur de la propri�t� titre.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitre() {
        return titre;
    }

    /**
     * D�finit la valeur de la propri�t� titre.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitre(String value) {
        this.titre = value;
    }

    /**
     * Obtient la valeur de la propri�t� prixJour.
     * 
     */
    public double getPrixJour() {
        return prixJour;
    }

    /**
     * D�finit la valeur de la propri�t� prixJour.
     * 
     */
    public void setPrixJour(double value) {
        this.prixJour = value;
    }

    /**
     * Obtient la valeur de la propri�t� emprunte.
     * 
     */
    public boolean isEmprunte() {
        return emprunte;
    }

    /**
     * D�finit la valeur de la propri�t� emprunte.
     * 
     */
    public void setEmprunte(boolean value) {
        this.emprunte = value;
    }

}
