
import java.util.Scanner;
import java.util.List;

import service.BibliothequeWS;
import service.BibliothequeException_Exception;
import service.BibliothequeService;
import service.Livre;

public class BiblioClient {

    public static void main(String[] args) {

        BibliothequeService proxy =
                new BibliothequeWS().getBibliothequeServicePort();

        Scanner sc = new Scanner(System.in);
        int choix;

        do {
            System.out.println("\n===== MENU BIBLIOTHÈQUE =====");
            System.out.println("1- Consulter un livre");
            System.out.println("2- Afficher tous les livres");
            System.out.println("3- Emprunter un livre");
            System.out.println("4- Retourner un livre");
            System.out.println("5- Calculer le montant");
            System.out.println("0- Quitter");
            System.out.print("Votre choix : ");
            choix = sc.nextInt();

            try {
                switch (choix) {

                case 1:
                    System.out.print("ID livre : ");
                    int id = sc.nextInt();
                    Livre l = proxy.getLivre(id);
                    System.out.println(
                            "ID : " + l.getId() +
                            " | Titre : " + l.getTitre() +
                            " | Prix/Jour : " + l.getPrixJour() +
                            " | Emprunté : " + l.isEmprunte()
                        );
                    break;

                case 2:
                    List<Livre> livres = proxy.afficherTousLesLivres();
                    for (Livre lv : livres)
                    	System.out.println(
                                "ID : " + lv.getId() +
                                " | Titre : " + lv.getTitre() +
                                " | Prix/Jour : " + lv.getPrixJour() +
                                " | Emprunté : " + lv.isEmprunte()
                            );
                    break;

                case 3:
                    System.out.print("ID livre : ");
                    proxy.emprunterLivre(sc.nextInt());
                    System.out.println("Livre emprunté avec succès");
                    break;

                case 4:
                    System.out.print("ID livre : ");
                    proxy.retournerLivre(sc.nextInt());
                    System.out.println("Livre retourné avec succès");
                    break;

                case 5:
                    System.out.print("ID livre : ");
                    id = sc.nextInt();
                    System.out.print("Nombre de jours : ");
                    int jours = sc.nextInt();
                    double montant = proxy.calculerMontant(id, jours);
                    System.out.println("Montant à payer = " + montant);
                    break;

                case 0:
                    System.out.println("Fin du programme");
                    break;

                default:
                    System.out.println("Choix invalide");
                }

            } catch (BibliothequeException_Exception e) {
                System.out.println("Erreur : " + e.getMessage());
            }

        } while (choix != 0);
    }
}
